<?php include('header.php'); ?>

<div>;
<div class="container text-center align-middle text-white place-above">
    <h1>Hey you!</h1>
    <h3>This page doesn't exist!<h3>  
    <h3>Sorry 404-page!</h3><a href="index.php" class="btn btn-secondary btn-me active mt-1" role="button" aria-pressed="true">Return</a>
</div>
</div>;

<?php include('footer.php');?>
</html>